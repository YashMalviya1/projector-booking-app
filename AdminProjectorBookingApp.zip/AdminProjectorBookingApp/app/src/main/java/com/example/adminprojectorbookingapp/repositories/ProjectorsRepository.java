package com.example.adminprojectorbookingapp.repositories;

import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.adminprojectorbookingapp.models.Projectors;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ProjectorsRepository {
    private DatabaseReference db;
    private MutableLiveData<List<Projectors>> avHallList;

    public interface AVHallCallback{
        public void onAVHallRegistered();
    }
    public ProjectorsRepository() {
        db = FirebaseDatabase.getInstance().getReference();
        avHallList = new MutableLiveData<>();
        loadProjectors();
    }

    public void AddProjector(Projectors projectors) {
        String key = db.child("AVHalls").push().getKey();
        System.out.println("key :" + key);
        projectors.setProjectorUid(key);
        db.child("AVHalls").child(key).setValue(projectors);
    }

    public LiveData<List<Projectors>> getProjectors() {
        return avHallList;
    }

    public void loadProjectors() {
        db.child("AVHalls").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<Projectors> projectors = new ArrayList<>();

                for(DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Projectors projector = dataSnapshot.getValue(Projectors.class);
                    System.out.println(" Projectors "+projector.toString());
                    projectors.add(projector);
                }
                avHallList.postValue(projectors);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("UserRepository", "Failed to load Halls: " + error.getMessage());
            }
        });
    }

}
