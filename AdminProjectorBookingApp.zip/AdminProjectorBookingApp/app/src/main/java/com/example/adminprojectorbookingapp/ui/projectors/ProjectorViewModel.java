package com.example.adminprojectorbookingapp.ui.projectors;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.adminprojectorbookingapp.models.Projectors;

import com.example.adminprojectorbookingapp.models.Projectors;
import com.example.adminprojectorbookingapp.repositories.ProjectorsRepository;

import java.util.List;

public class ProjectorViewModel extends ViewModel {

    private ProjectorsRepository projectorsRepository;
    private MutableLiveData<List<Projectors>> hallList = new MutableLiveData<>();

    public ProjectorViewModel() {
        projectorsRepository = new ProjectorsRepository();
        getAvHalls();
    }
    public void addProjector(Projectors avHall) {
        projectorsRepository.AddProjector(avHall);
    }

    public LiveData<List<Projectors>> getAvHalls() {
        if(hallList.getValue()==null) {
            hallList = (MutableLiveData<List<Projectors>>) projectorsRepository.getProjectors();
        }
        return hallList;
    }
}