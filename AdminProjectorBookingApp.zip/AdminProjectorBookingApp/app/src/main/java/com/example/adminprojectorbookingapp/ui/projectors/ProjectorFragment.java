package com.example.adminprojectorbookingapp.ui.projectors;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.adminprojectorbookingapp.adapters.ProjectorAdapter;
import com.example.adminprojectorbookingapp.models.Projectors;
import com.example.adminprojectorbookingapp.R;
import com.example.adminprojectorbookingapp.databinding.FragmentProjectorBinding;

import java.util.ArrayList;

public class ProjectorFragment extends Fragment {


    private FragmentProjectorBinding binding;
    private com.example.adminprojectorbookingapp.ui.projectors.ProjectorViewModel projectorViewModel;
    private ProjectorAdapter projectorAdapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        com.example.adminprojectorbookingapp.ui.projectors.ProjectorViewModel projectorViewModel = new ViewModelProvider(this).get(com.example.adminprojectorbookingapp.ui.projectors.ProjectorViewModel.class);

        binding = FragmentProjectorBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Dialog dialog = new Dialog(getContext());
        projectorViewModel = new ViewModelProvider(this).get(com.example.adminprojectorbookingapp.ui.projectors.ProjectorViewModel.class);

        projectorAdapter = new ProjectorAdapter();
        binding.recyclerView.setAdapter(projectorAdapter);

        projectorViewModel.getAvHalls().observe(getViewLifecycleOwner(), projectors -> {
            projectorAdapter.setHalls((ArrayList<Projectors>) projectors);
            projectorAdapter.notifyDataSetChanged();

        });

        binding.AddHallBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.setContentView(R.layout.add_projector_dialog);
                dialog.show();
                dialog.setCancelable(false);
                Button OkBtn = dialog.findViewById(R.id.done_btn);
                OkBtn.setOnClickListener(view1 -> {


                    EditText HallNameET = dialog.findViewById(R.id.hall_name_et);
                    EditText HallLocationET = dialog.findViewById(R.id.hall_location_et);
                    EditText HallCapacityET = dialog.findViewById(R.id.hall_capacity_et);
                    EditText DeptET = dialog.findViewById(R.id.hall_dept_et);

                    String HallName = HallNameET.getText().toString();
                    String HallLocation = HallLocationET.getText().toString();
                    String HallCapacity = HallCapacityET.getText().toString();
                    String Dept = DeptET.getText().toString();

                    Projectors hall = new Projectors();

                    //Validation
                    if(HallName.isEmpty()) {
                        Toast.makeText(getContext(), "Please specify the hall name", Toast.LENGTH_SHORT).show();
                    }
                    else if(HallLocation.isEmpty()) {
                        Toast.makeText(getContext(), "Please specify the hall location", Toast.LENGTH_SHORT).show();
                    }
                    else if(HallCapacity.isEmpty()) {
                        Toast.makeText(getContext(), "Please specify the hall capacity", Toast.LENGTH_SHORT).show();
                    }
                    else if(Dept.isEmpty()) {
                        Toast.makeText(getContext(), "Please specify the department", Toast.LENGTH_SHORT).show();
                    }

                    else{
                        hall.setName(HallName);
                        hall.setLocation(HallLocation);
                        hall.setCapacity(Integer.parseInt(HallCapacity));
                        hall.setDept(Dept);

                        projectorViewModel.addProjector(hall);
                        Toast.makeText(getContext(), "SENDING DATA", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }


                });

                ImageView Cancel = dialog.findViewById(R.id.CancelBtn);
                Cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

            }
        });

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}