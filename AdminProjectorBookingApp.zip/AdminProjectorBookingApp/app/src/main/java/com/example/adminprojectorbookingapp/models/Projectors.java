package com.example.adminprojectorbookingapp.models;

public class Projectors {
    private String projectorUid;
    private String name;
    private String location;
    private int capacity;
    private String dept;

    public String getProjectorUid() {
        return projectorUid;
    }

    public void setProjectorUid(String avHallUid) {
        this.projectorUid = avHallUid;
    }



    public Projectors() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }
}

