package com.example.adminprojectorbookingapp.repositories;

import com.example.adminprojectorbookingapp.ui.teachers.SendMail;
import com.example.adminprojectorbookingapp.ui.teachers.Teacher;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;



public class RegisterTeacherFramentRepository {
    public interface RegisterCallBack{
        public void onRegisterComplete();
    }
    DatabaseReference dbRef;
    RegisterTeacherFramentRepository(){

    }
    Teacher teacher;

    public RegisterTeacherFramentRepository(String firstName, String lastName, String gmail, String phoneNumber) {
        dbRef = FirebaseDatabase.getInstance().getReference();
        teacher = new Teacher();
        teacher.setFirstName(firstName);
        teacher.setLastName(lastName);
        teacher.setFcmToken("");
        teacher.setGmail(gmail);
        teacher.setPhoneNumber(phoneNumber);
    }

    public void registerUser(RegisterCallBack registerCallBack) {

        registerUserToFirebaseAuth(registerCallBack);


    }

    private void registerUserToFirebaseAuth(RegisterCallBack registerCallBack) {
        FirebaseAuth.getInstance().createUserWithEmailAndPassword(teacher.getGmail(),"abcdefghi").addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                teacher.setUid(authResult.getUser().getUid());
                UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                        .setDisplayName(teacher.getFirstName())
                        .build();
                authResult.getUser().updateProfile(profileUpdates);
                dbRef.child("Teachers").child(authResult.getUser().getUid()).setValue(teacher).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        registerCallBack.onRegisterComplete();
                        SendMail sendMail = new SendMail();
                        sendMail.sendmailToGmail(teacher.getGmail());
                        registerUserToFirebaseAuth(registerCallBack);
                    }
                });
            }
        });
    }
}
