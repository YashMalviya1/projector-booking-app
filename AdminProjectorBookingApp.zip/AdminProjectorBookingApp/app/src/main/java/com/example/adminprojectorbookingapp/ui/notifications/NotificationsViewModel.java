package com.example.adminprojectorbookingapp.ui.notifications;

import androidx.lifecycle.ViewModel;

public class NotificationsViewModel extends ViewModel {
}